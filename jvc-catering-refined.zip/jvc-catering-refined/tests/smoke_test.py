from pathlib import Path
from playwright.sync_api import sync_playwright
import json
import mimetypes
import re

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'tests' / 'results'
OUT.mkdir(parents=True, exist_ok=True)

html = (ROOT / 'index.html').read_text(encoding='utf-8')
html = html.replace('<head>', '<head><base href="http://jvc.local/">', 1)


def route_local(route):
    url = route.request.url
    if not url.startswith('http://jvc.local/'):
        route.continue_()
        return
    relative = url.split('http://jvc.local/', 1)[1].split('?', 1)[0]
    if not relative:
        relative = 'index.html'
    file_path = ROOT / relative
    if file_path.is_file():
        route.fulfill(
            path=str(file_path),
            content_type=mimetypes.guess_type(str(file_path))[0] or 'application/octet-stream'
        )
    else:
        route.fulfill(status=404, body='Not found')


def accessibility_snapshot(page):
    return page.evaluate(r"""() => {
      const text = (element) => (element.innerText || element.textContent || '').trim().replace(/\s+/g, ' ');
      const name = (element) => element.getAttribute('aria-label') || text(element);
      const visible = (element) => {
        const style = getComputedStyle(element);
        const rect = element.getBoundingClientRect();
        return style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
      };
      const controls = [...document.querySelectorAll('a[href], button, input, select, textarea')].filter(visible).filter((element) => !(element.matches('input[type=radio]') && element.closest('label')));
      const duplicateIds = [...document.querySelectorAll('[id]')]
        .map((element) => element.id)
        .filter((id, index, ids) => ids.indexOf(id) !== index);
      return {
        h1Count: document.querySelectorAll('h1').length,
        mainCount: document.querySelectorAll('main').length,
        missingAlt: document.querySelectorAll('img:not([alt])').length,
        emptyLinks: [...document.querySelectorAll('a[href]')].filter((element) => !name(element)).length,
        emptyButtons: [...document.querySelectorAll('button')].filter((element) => !name(element)).length,
        hashLinks: [...document.querySelectorAll('a[href="#"]')].length,
        targetBlankUnsafe: [...document.querySelectorAll('a[target="_blank"]')].filter((element) => !/(noopener|noreferrer)/.test(element.rel)).length,
        duplicateIds: [...new Set(duplicateIds)],
        horizontalOverflow: document.documentElement.scrollWidth > document.documentElement.clientWidth,
        viewportWidth: document.documentElement.clientWidth,
        documentWidth: document.documentElement.scrollWidth,
        unlabeledFields: [...document.querySelectorAll('input, textarea, select')].filter((field) => {
          if (field.type === 'hidden') return false;
          if (field.getAttribute('aria-label') || field.getAttribute('aria-labelledby')) return false;
          if (field.id && document.querySelector(`label[for="${CSS.escape(field.id)}"]`)) return false;
          return !field.closest('label');
        }).length,
        tinyControls: controls.map((element) => {
          const rect = element.getBoundingClientRect();
          return { tag: element.tagName, name: name(element), width: Math.round(rect.width), height: Math.round(rect.height) };
        }).filter((item) => item.width < 44 || item.height < 44),
        failedImages: [...document.images].filter((image) => image.complete && image.naturalWidth === 0).map((image) => image.src)
      };
    }""")


results = {}
with sync_playwright() as playwright:
    browser = playwright.chromium.launch(
        headless=True,
        executable_path='/usr/bin/chromium',
        args=['--no-sandbox']
    )

    for name, viewport in {
        'mobile': {'width': 390, 'height': 844},
        'tablet': {'width': 768, 'height': 1024},
        'desktop': {'width': 1440, 'height': 1000}
    }.items():
        context = browser.new_context(viewport=viewport, reduced_motion='reduce')
        page = context.new_page()
        page.set_default_timeout(5000)
        page.route('**/*', route_local)
        page.add_init_script("""window.__openedUrl = ''; window.open = (url) => { window.__openedUrl = url; return { opener: null }; };""")

        console_errors = []
        page_errors = []
        failed_requests = []
        page.on('console', lambda message, output=console_errors: output.append(message.text) if message.type == 'error' else None)
        page.on('pageerror', lambda error, output=page_errors: output.append(str(error)))
        page.on('requestfailed', lambda request, output=failed_requests: output.append({'url': request.url, 'error': str(request.failure)}))

        page.set_content(html, wait_until='load', timeout=90000)
        page.wait_for_timeout(800)
        # Trigger lazy-loaded content and each hidden menu panel before checking image health.
        page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        page.wait_for_timeout(500)
        for tab in page.locator('[data-menu-tab]').all():
            tab.click()
            page.wait_for_timeout(150)
        page.locator('[data-menu-tab]').first.click()
        page.wait_for_timeout(500)
        page.wait_for_timeout(1000)

        interactions = {}
        if name == 'mobile':
            toggle = page.locator('[data-menu-toggle]')
            toggle.click()
            interactions['menuOpened'] = toggle.get_attribute('aria-expanded') == 'true'
            interactions['menuFocusedFirstLink'] = page.evaluate("document.activeElement === document.querySelector('[data-navigation] a')")
            page.keyboard.press('Escape')
            interactions['menuClosedWithEscape'] = toggle.get_attribute('aria-expanded') == 'false'

            toggle.click()
            page.locator('.mobile-language-switcher [data-language="sw"]').click()
            interactions['languageChanged'] = page.locator('html').get_attribute('lang') == 'sw'
            page.locator('.mobile-language-switcher [data-language="en"]').click()
            page.keyboard.press('Escape')

            tabs = page.locator('[data-menu-tab]')
            tabs.nth(0).focus()
            page.keyboard.press('ArrowRight')
            interactions['tabKeyboardNavigation'] = tabs.nth(1).get_attribute('aria-selected') == 'true'

            page.locator('label:has(input[name="eventType"][value="Wedding"])').click()
            page.locator('[data-form-next]').click()
            page.locator('#customer-name').fill('Test Customer')
            page.locator('#customer-phone').fill('+255700000000')
            page.locator('#event-date').fill('2026-12-20')
            page.locator('#guest-count').fill('120')
            page.locator('#event-location').fill('Dar es Salaam')
            page.locator('[data-form-next]').click()
            interactions['formReachedSummary'] = page.locator('[data-form-step="3"]').is_visible()
            page.locator('[data-form-submit]').click()
            opened_url = page.evaluate('window.__JVC_LAST_WHATSAPP_URL__ || window.__openedUrl')
            interactions['whatsappUrlCreated'] = opened_url.startswith('https://wa.me/255767602509?text=')
            interactions['whatsappMessageEncoded'] = '%0A' in opened_url and 'Test%20Customer' in opened_url

        snapshot = accessibility_snapshot(page)
        results[name] = {
            'accessibility': snapshot,
            'interactions': interactions,
            'consoleErrors': console_errors,
            'pageErrors': page_errors,
            'failedRequests': failed_requests
        }
        context.close()

    browser.close()

(OUT / 'smoke-results.json').write_text(json.dumps(results, indent=2), encoding='utf-8')

failures = []
for viewport, result in results.items():
    audit = result['accessibility']
    for key in ('missingAlt', 'emptyLinks', 'emptyButtons', 'hashLinks', 'targetBlankUnsafe', 'unlabeledFields'):
        if audit[key] != 0:
            failures.append(f'{viewport}: {key}={audit[key]}')
    if audit['h1Count'] != 1:
        failures.append(f'{viewport}: h1Count={audit["h1Count"]}')
    if audit['mainCount'] != 1:
        failures.append(f'{viewport}: mainCount={audit["mainCount"]}')
    if audit['horizontalOverflow']:
        failures.append(f'{viewport}: horizontal overflow')
    if audit['duplicateIds']:
        failures.append(f'{viewport}: duplicate IDs {audit["duplicateIds"]}')
    if audit['failedImages']:
        failures.append(f'{viewport}: failed images {audit["failedImages"]}')
    if result['consoleErrors'] or result['pageErrors'] or result['failedRequests']:
        failures.append(f'{viewport}: runtime/network errors')

mobile = results['mobile']['interactions']
for key, passed in mobile.items():
    if not passed:
        failures.append(f'mobile interaction failed: {key}')

print(json.dumps(results, indent=2))
if failures:
    print('\nFAILURES:')
    for failure in failures:
        print('-', failure)
    raise SystemExit(1)
print('\nAll smoke tests passed.')
