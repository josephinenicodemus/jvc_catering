'use strict';

document.documentElement.classList.add('js');

const PRIMARY_WHATSAPP = '255767602509';

const translations = {
  en: {
    pageTitle: 'JVC Catering Tanzania | Weddings & Corporate Events',
    pageDescription: 'Authentic Tanzanian catering in Dar es Salaam for weddings, corporate events and private celebrations. Request a tailored menu and quotation from JVC Catering.',
    skip: 'Skip to main content',
    'nav.home': 'Home',
    'nav.about': 'About',
    'nav.services': 'Services',
    'nav.menu': 'Menu',
    'nav.clients': 'Clients',
    'nav.contact': 'Contact',
    'nav.quote': 'Get a quote',
    'hero.badge': 'Dar es Salaam, Tanzania · Established 2016',
    'hero.title': 'Authentic Tanzanian catering for memorable events',
    'hero.lead': 'Tailored menus, warm hospitality and dependable service for weddings, corporate events and private celebrations.',
    'hero.quote': 'Request a quote',
    'hero.menu': 'Explore the menu',
    'stats.events': 'events catered',
    'stats.experience': 'years of experience',
    'stats.partners': 'trusted partners',
    'about.eyebrow': 'Our story',
    'about.title': 'The heart behind JVC Catering',
    'about.p1': "JVC Catering grew from founder Veronica Nguma's passion for cooking and connecting with people through memorable meals.",
    'about.p2': 'With more than 25 years of experience, Veronica built a business grounded in authenticity, creativity, dependable service and fresh ingredients.',
    'about.quote': '“Tailored Tastes. Warm Moments. Spectacular Impressions.”',
    'values.quality.title': 'Quality',
    'values.quality.text': 'Fresh ingredients and care in every detail.',
    'values.reliability.title': 'Reliability',
    'values.reliability.text': 'Prepared, punctual and committed.',
    'values.flexibility.title': 'Flexibility',
    'values.flexibility.text': 'Menus and service adapted to your event.',
    'values.authenticity.title': 'Authenticity',
    'values.authenticity.text': 'Genuine Tanzanian flavours and hospitality.',
    'services.eyebrow': 'What we offer',
    'services.title': 'Professional catering for every occasion',
    'services.lead': 'Each event receives a tailored menu, polished presentation and attentive service.',
    'services.wedding.title': 'Wedding catering',
    'services.wedding.text': 'Celebrate with a tailored Tanzanian or international menu and organised event service.',
    'services.wedding.item1': 'Custom menu planning',
    'services.wedding.item2': 'Buffet or plated service',
    'services.wedding.item3': 'Professional service team',
    'services.corporate.title': 'Corporate events',
    'services.corporate.text': 'Dependable catering for meetings, conferences, launches and executive hospitality.',
    'services.corporate.item1': 'Business lunch packages',
    'services.corporate.item2': 'Conference catering',
    'services.corporate.item3': 'Takeaway and delivery',
    'services.private.title': 'Private celebrations',
    'services.private.text': 'Food and hospitality for birthdays, anniversaries, engagements and family gatherings.',
    'services.private.item1': 'Flexible guest packages',
    'services.private.item2': 'Custom themes',
    'services.private.item3': 'Home or venue service',
    'services.cta': 'Request a quote',
    'menu.eyebrow': 'Tanzanian flavours',
    'menu.title': 'Explore our menu',
    'menu.lead': 'A selection of familiar favourites prepared with fresh ingredients. Final menus are tailored to your event.',
    'menu.tabs.starters': 'Starters',
    'menu.tabs.mains': 'Mains',
    'menu.tabs.desserts': 'Desserts',
    'menu.tabs.beverages': 'Beverages',
    'menu.note': 'Need a complete event menu and pricing?',
    'menu.cta': 'Request a tailored menu',
    'food.maandazi': 'Soft East African fried bread, lightly sweetened.',
    'food.kitumbua': 'Coconut and cardamom rice pancakes.',
    'food.kachori': 'Golden bites filled with seasoned lentils or potatoes.',
    'food.mishkaki': 'Marinated beef skewers grilled over charcoal.',
    'food.pilau': 'Fragrant rice cooked with warming spices and tender meat.',
    'food.nyamachoma': 'Fire-grilled meat served with fresh accompaniments.',
    'food.walinazi': 'Coconut rice served with a richly seasoned main dish.',
    'food.maharage': 'Slow-cooked beans with Tanzanian spices.',
    'food.ndizi': 'Green banana and beef stew with a comforting sauce.',
    'food.halwa': 'A fragrant, rich sweet finished with warming spice.',
    'food.pudding': 'Creamy coconut dessert with a delicate finish.',
    'food.honey': 'Soft maandazi finished with honey.',
    'food.sugarcane': 'Freshly pressed with lemon and ginger.',
    'food.chai': 'Warm tea infused with ginger and aromatic spices.',
    'food.cocktail': 'Colourful event drinks prepared to suit your occasion.',
    'food.beveragesTitle': 'Assorted Beverages',
    'food.beverages': 'Water, soft drinks and non-alcoholic event options.',
    'clients.eyebrow': 'Experience and trust',
    'clients.title': 'Organisations served by JVC Catering',
    'clients.lead': 'From development organisations to private businesses, every engagement receives the same professional care.',
    'contact.eyebrow': 'Get in touch',
    'contact.title': 'Request a catering quote',
    'contact.lead': 'Share the essential event details and send your request directly to Veronica through WhatsApp.',
    'contact.whatsapp': 'WhatsApp',
    'contact.phone': 'Phone',
    'contact.phone2': 'Alternative phone',
    'contact.email': 'Email',
    'contact.address': 'Address',
    'form.progress.event': 'Event',
    'form.progress.details': 'Details',
    'form.progress.confirm': 'Confirm',
    'form.step1.title': 'What is the occasion?',
    'form.step1.help': 'Select one event type.',
    'form.step2.title': 'Tell us about the event',
    'form.step3.title': 'Review your request',
    'form.name': 'Your name',
    'form.phone': 'Phone number',
    'form.date': 'Event date',
    'form.guests': 'Estimated guests',
    'form.location': 'Event location',
    'form.notes': 'Menu preferences or additional notes',
    'form.privacy': 'Your information is used only to create the WhatsApp quotation message.',
    'form.back': 'Back',
    'form.next': 'Continue',
    'form.submit': 'Send with WhatsApp',
    'events.wedding': 'Wedding',
    'events.corporate': 'Corporate',
    'events.birthday': 'Birthday',
    'events.anniversary': 'Anniversary',
    'events.party': 'Party',
    'events.other': 'Other',
    'cta.eyebrow': 'Plan your event',
    'cta.title': 'Ready to create a memorable dining experience?',
    'cta.button': 'Chat with Veronica',
    'footer.description': 'Authentic Tanzanian catering, warm hospitality and dependable event service.',
    'footer.navigation': 'Navigation',
    'footer.services': 'Services',
    'footer.delivery': 'Takeaway and delivery',
    'footer.contact': 'Contact',
    'footer.rights': 'All rights reserved.',
    'footer.privacy': 'Privacy notice',
    'footer.terms': 'Website terms',
    whatsapp: 'WhatsApp quote',
    menuOpen: 'Open navigation menu',
    menuClose: 'Close navigation menu',
    validationEvent: 'Choose an event type before continuing.',
    validationFields: 'Review the highlighted fields and provide the required information.',
    summaryEvent: 'Event',
    summaryName: 'Name',
    summaryPhone: 'Phone',
    summaryDate: 'Date',
    summaryGuests: 'Guests',
    summaryLocation: 'Location',
    whatsappHeading: 'NEW CATERING INQUIRY — JVC Catering',
    whatsappClosing: 'Please share menu options, pricing and availability.'
  },
  sw: {
    pageTitle: 'JVC Catering Tanzania | Harusi na Matukio ya Kampuni',
    pageDescription: 'Huduma halisi za upishi wa Kitanzania Dar es Salaam kwa harusi, matukio ya kampuni na sherehe binafsi.',
    skip: 'Ruka hadi maudhui makuu',
    'nav.home': 'Mwanzo',
    'nav.about': 'Kuhusu',
    'nav.services': 'Huduma',
    'nav.menu': 'Menyu',
    'nav.clients': 'Wateja',
    'nav.contact': 'Mawasiliano',
    'nav.quote': 'Omba bei',
    'hero.badge': 'Dar es Salaam, Tanzania · Ilianzishwa 2016',
    'hero.title': 'Upishi halisi wa Kitanzania kwa matukio ya kukumbukwa',
    'hero.lead': 'Menyu maalum, ukarimu wa dhati na huduma ya kuaminika kwa harusi, matukio ya kampuni na sherehe binafsi.',
    'hero.quote': 'Omba bei',
    'hero.menu': 'Angalia menyu',
    'stats.events': 'matukio yaliyohudumiwa',
    'stats.experience': 'miaka ya uzoefu',
    'stats.partners': 'washirika wa kuaminika',
    'about.eyebrow': 'Hadithi yetu',
    'about.title': 'Moyo wa JVC Catering',
    'about.p1': 'JVC Catering ilikua kutokana na shauku ya mwanzilishi Veronica Nguma ya kupika na kuunganisha watu kupitia chakula cha kukumbukwa.',
    'about.p2': 'Akiwa na uzoefu wa zaidi ya miaka 25, Veronica alijenga biashara yenye uhalisia, ubunifu, huduma ya kuaminika na viungo safi.',
    'about.quote': '“Ladha Zilizoundwa. Wakati wa Furaha. Hisia za Kipekee.”',
    'values.quality.title': 'Ubora',
    'values.quality.text': 'Viungo safi na umakini katika kila jambo.',
    'values.reliability.title': 'Kuaminika',
    'values.reliability.text': 'Tumejiandaa, tunazingatia muda na tunajituma.',
    'values.flexibility.title': 'Unyumbufu',
    'values.flexibility.text': 'Menyu na huduma kulingana na tukio lako.',
    'values.authenticity.title': 'Uhalisia',
    'values.authenticity.text': 'Ladha na ukarimu halisi wa Kitanzania.',
    'services.eyebrow': 'Tunachotoa',
    'services.title': 'Huduma ya kitaalamu kwa kila tukio',
    'services.lead': 'Kila tukio hupata menyu maalum, mpangilio mzuri na huduma makini.',
    'services.wedding.title': 'Upishi wa harusi',
    'services.wedding.text': 'Sherehekea kwa menyu maalum ya Kitanzania au kimataifa na huduma iliyopangwa vizuri.',
    'services.wedding.item1': 'Upangaji wa menyu maalum',
    'services.wedding.item2': 'Buffet au huduma ya mezani',
    'services.wedding.item3': 'Timu ya huduma ya kitaalamu',
    'services.corporate.title': 'Matukio ya kampuni',
    'services.corporate.text': 'Upishi wa kuaminika kwa mikutano, makongamano, uzinduzi na wageni wa kampuni.',
    'services.corporate.item1': 'Vifurushi vya chakula cha mchana',
    'services.corporate.item2': 'Upishi wa makongamano',
    'services.corporate.item3': 'Takeaway na delivery',
    'services.private.title': 'Sherehe binafsi',
    'services.private.text': 'Chakula na ukarimu kwa siku za kuzaliwa, maadhimisho, uchumba na mikusanyiko ya familia.',
    'services.private.item1': 'Vifurushi vinavyobadilika',
    'services.private.item2': 'Mandhari maalum',
    'services.private.item3': 'Huduma nyumbani au ukumbini',
    'services.cta': 'Omba bei',
    'menu.eyebrow': 'Ladha za Tanzania',
    'menu.title': 'Angalia menyu yetu',
    'menu.lead': 'Baadhi ya vyakula pendwa vinavyotayarishwa kwa viungo safi. Menyu ya mwisho huandaliwa kwa tukio lako.',
    'menu.tabs.starters': 'Vitafunwa',
    'menu.tabs.mains': 'Vyakula vikuu',
    'menu.tabs.desserts': 'Vitamu',
    'menu.tabs.beverages': 'Vinywaji',
    'menu.note': 'Unahitaji menyu kamili na bei?',
    'menu.cta': 'Omba menyu maalum',
    'food.maandazi': 'Maandazi laini ya Afrika Mashariki yenye utamu wa kiasi.',
    'food.kitumbua': 'Vitumbua vya nazi na iliki.',
    'food.kachori': 'Vitafunwa vya dhahabu vyenye dengu au viazi vilivyokolezwa.',
    'food.mishkaki': 'Mishkaki ya nyama iliyolowekwa viungo na kuchomwa kwa mkaa.',
    'food.pilau': 'Wali wenye harufu ya viungo na nyama laini.',
    'food.nyamachoma': 'Nyama iliyochomwa na kuandaliwa na viambata safi.',
    'food.walinazi': 'Wali wa nazi unaotolewa na kitoweo chenye viungo.',
    'food.maharage': 'Maharage yaliyopikwa taratibu kwa viungo vya Kitanzania.',
    'food.ndizi': 'Mchuzi wa ndizi mbichi na nyama wenye ladha ya nyumbani.',
    'food.halwa': 'Kitamu chenye harufu nzuri ya viungo.',
    'food.pudding': 'Pudingi laini ya nazi.',
    'food.honey': 'Maandazi laini yenye asali.',
    'food.sugarcane': 'Juisi iliyokamuliwa na limau pamoja na tangawizi.',
    'food.chai': 'Chai ya moto yenye tangawizi na viungo.',
    'food.cocktail': 'Vinywaji vya rangi vinavyolingana na tukio lako.',
    'food.beveragesTitle': 'Vinywaji Mbalimbali',
    'food.beverages': 'Maji, soda na vinywaji visivyo na kilevi.',
    'clients.eyebrow': 'Uzoefu na uaminifu',
    'clients.title': 'Mashirika yaliyohudumiwa na JVC Catering',
    'clients.lead': 'Kutoka mashirika ya maendeleo hadi biashara binafsi, kila tukio hupata huduma ya kitaalamu.',
    'contact.eyebrow': 'Wasiliana nasi',
    'contact.title': 'Omba bei ya upishi',
    'contact.lead': 'Tuma maelezo muhimu ya tukio moja kwa moja kwa Veronica kupitia WhatsApp.',
    'contact.whatsapp': 'WhatsApp',
    'contact.phone': 'Simu',
    'contact.phone2': 'Simu nyingine',
    'contact.email': 'Barua pepe',
    'contact.address': 'Anwani',
    'form.progress.event': 'Tukio',
    'form.progress.details': 'Maelezo',
    'form.progress.confirm': 'Thibitisha',
    'form.step1.title': 'Ni tukio gani?',
    'form.step1.help': 'Chagua aina moja ya tukio.',
    'form.step2.title': 'Tuambie kuhusu tukio',
    'form.step3.title': 'Kagua ombi lako',
    'form.name': 'Jina lako',
    'form.phone': 'Namba ya simu',
    'form.date': 'Tarehe ya tukio',
    'form.guests': 'Idadi ya wageni',
    'form.location': 'Eneo la tukio',
    'form.notes': 'Mapendeleo ya menyu au maelezo mengine',
    'form.privacy': 'Maelezo yako yanatumika tu kutengeneza ujumbe wa ombi kwenye WhatsApp.',
    'form.back': 'Rudi',
    'form.next': 'Endelea',
    'form.submit': 'Tuma kwa WhatsApp',
    'events.wedding': 'Harusi',
    'events.corporate': 'Kampuni',
    'events.birthday': 'Siku ya kuzaliwa',
    'events.anniversary': 'Maadhimisho',
    'events.party': 'Sherehe',
    'events.other': 'Nyingine',
    'cta.eyebrow': 'Panga tukio lako',
    'cta.title': 'Uko tayari kuunda uzoefu wa chakula wa kukumbukwa?',
    'cta.button': 'Ongea na Veronica',
    'footer.description': 'Upishi halisi wa Kitanzania, ukarimu na huduma ya tukio ya kuaminika.',
    'footer.navigation': 'Urambazaji',
    'footer.services': 'Huduma',
    'footer.delivery': 'Takeaway na delivery',
    'footer.contact': 'Mawasiliano',
    'footer.rights': 'Haki zote zimehifadhiwa.',
    'footer.privacy': 'Taarifa ya faragha',
    'footer.terms': 'Masharti ya tovuti',
    whatsapp: 'Omba bei WhatsApp',
    menuOpen: 'Fungua menyu ya urambazaji',
    menuClose: 'Funga menyu ya urambazaji',
    validationEvent: 'Chagua aina ya tukio kabla ya kuendelea.',
    validationFields: 'Kagua sehemu zilizoonyeshwa na ujaze taarifa zinazohitajika.',
    summaryEvent: 'Tukio',
    summaryName: 'Jina',
    summaryPhone: 'Simu',
    summaryDate: 'Tarehe',
    summaryGuests: 'Wageni',
    summaryLocation: 'Eneo',
    whatsappHeading: 'OMBI JIPYA LA UPISHI — JVC Catering',
    whatsappClosing: 'Tafadhali tuma chaguo za menyu, bei na upatikanaji.'
  },
  fr: {
    pageTitle: "JVC Catering Tanzanie | Mariages et Événements d'Entreprise",
    pageDescription: 'Service traiteur tanzanien authentique à Dar es Salaam pour mariages, événements professionnels et célébrations privées.',
    skip: 'Aller au contenu principal',
    'nav.home': 'Accueil',
    'nav.about': 'À propos',
    'nav.services': 'Services',
    'nav.menu': 'Menu',
    'nav.clients': 'Clients',
    'nav.contact': 'Contact',
    'nav.quote': 'Demander un devis',
    'hero.badge': 'Dar es Salaam, Tanzanie · Fondé en 2016',
    'hero.title': 'Cuisine tanzanienne authentique pour des événements mémorables',
    'hero.lead': "Menus sur mesure, accueil chaleureux et service fiable pour mariages, événements d'entreprise et célébrations privées.",
    'hero.quote': 'Demander un devis',
    'hero.menu': 'Explorer le menu',
    'stats.events': 'événements servis',
    'stats.experience': "années d'expérience",
    'stats.partners': 'partenaires de confiance',
    'about.eyebrow': 'Notre histoire',
    'about.title': 'Le cœur de JVC Catering',
    'about.p1': 'JVC Catering est né de la passion de sa fondatrice Veronica Nguma pour la cuisine et les liens créés autour de repas mémorables.',
    'about.p2': "Avec plus de 25 ans d'expérience, Veronica a bâti une entreprise fondée sur l'authenticité, la créativité, la fiabilité et des ingrédients frais.",
    'about.quote': '« Saveurs sur mesure. Moments chaleureux. Impressions spectaculaires. »',
    'values.quality.title': 'Qualité',
    'values.quality.text': 'Des ingrédients frais et du soin dans chaque détail.',
    'values.reliability.title': 'Fiabilité',
    'values.reliability.text': 'Préparés, ponctuels et engagés.',
    'values.flexibility.title': 'Flexibilité',
    'values.flexibility.text': 'Des menus et un service adaptés à votre événement.',
    'values.authenticity.title': 'Authenticité',
    'values.authenticity.text': 'Saveurs et hospitalité tanzaniennes authentiques.',
    'services.eyebrow': 'Nos services',
    'services.title': 'Un service traiteur professionnel pour chaque occasion',
    'services.lead': "Chaque événement bénéficie d'un menu personnalisé, d'une présentation soignée et d'un service attentif.",
    'services.wedding.title': 'Mariages',
    'services.wedding.text': 'Célébrez avec un menu tanzanien ou international sur mesure et un service bien organisé.',
    'services.wedding.item1': 'Planification du menu',
    'services.wedding.item2': 'Buffet ou service à table',
    'services.wedding.item3': 'Équipe de service professionnelle',
    'services.corporate.title': "Événements d'entreprise",
    'services.corporate.text': 'Service fiable pour réunions, conférences, lancements et accueil de direction.',
    'services.corporate.item1': "Formules déjeuner d'affaires",
    'services.corporate.item2': 'Restauration de conférence',
    'services.corporate.item3': 'À emporter et livraison',
    'services.private.title': 'Célébrations privées',
    'services.private.text': 'Cuisine et accueil pour anniversaires, fiançailles et réunions familiales.',
    'services.private.item1': 'Formules flexibles',
    'services.private.item2': 'Thèmes personnalisés',
    'services.private.item3': 'Service à domicile ou sur site',
    'services.cta': 'Demander un devis',
    'menu.eyebrow': 'Saveurs tanzaniennes',
    'menu.title': 'Explorez notre menu',
    'menu.lead': 'Une sélection de plats appréciés préparés avec des ingrédients frais. Le menu final est adapté à votre événement.',
    'menu.tabs.starters': 'Entrées',
    'menu.tabs.mains': 'Plats',
    'menu.tabs.desserts': 'Desserts',
    'menu.tabs.beverages': 'Boissons',
    'menu.note': 'Besoin du menu complet et des tarifs ?',
    'menu.cta': 'Demander un menu sur mesure',
    'food.maandazi': "Pain frit d'Afrique de l'Est, moelleux et légèrement sucré.",
    'food.kitumbua': 'Galettes de riz à la noix de coco et à la cardamome.',
    'food.kachori': 'Bouchées dorées garnies de lentilles ou de pommes de terre épicées.',
    'food.mishkaki': 'Brochettes de bœuf marinées et grillées au charbon.',
    'food.pilau': 'Riz parfumé aux épices et à la viande tendre.',
    'food.nyamachoma': 'Viande grillée au feu accompagnée de garnitures fraîches.',
    'food.walinazi': 'Riz à la noix de coco servi avec un plat principal épicé.',
    'food.maharage': 'Haricots mijotés aux épices tanzaniennes.',
    'food.ndizi': 'Ragoût réconfortant de banane verte et de bœuf.',
    'food.halwa': 'Douceur riche et parfumée aux épices.',
    'food.pudding': 'Dessert crémeux à la noix de coco.',
    'food.honey': 'Maandazi moelleux au miel.',
    'food.sugarcane': 'Jus fraîchement pressé au citron et au gingembre.',
    'food.chai': 'Thé chaud au gingembre et aux épices aromatiques.',
    'food.cocktail': 'Boissons colorées adaptées à votre événement.',
    'food.beveragesTitle': 'Boissons Assorties',
    'food.beverages': 'Eau, sodas et options sans alcool.',
    'clients.eyebrow': 'Expérience et confiance',
    'clients.title': 'Organisations servies par JVC Catering',
    'clients.lead': 'Des organismes de développement aux entreprises privées, chaque événement reçoit le même soin professionnel.',
    'contact.eyebrow': 'Contactez-nous',
    'contact.title': 'Demander un devis traiteur',
    'contact.lead': "Partagez les informations essentielles et envoyez votre demande directement à Veronica par WhatsApp.",
    'contact.whatsapp': 'WhatsApp',
    'contact.phone': 'Téléphone',
    'contact.phone2': 'Autre téléphone',
    'contact.email': 'E-mail',
    'contact.address': 'Adresse',
    'form.progress.event': 'Événement',
    'form.progress.details': 'Détails',
    'form.progress.confirm': 'Confirmer',
    'form.step1.title': "Quelle est l'occasion ?",
    'form.step1.help': "Sélectionnez un type d'événement.",
    'form.step2.title': "Parlez-nous de l'événement",
    'form.step3.title': 'Vérifiez votre demande',
    'form.name': 'Votre nom',
    'form.phone': 'Numéro de téléphone',
    'form.date': "Date de l'événement",
    'form.guests': 'Nombre estimé de personnes',
    'form.location': "Lieu de l'événement",
    'form.notes': 'Préférences de menu ou informations complémentaires',
    'form.privacy': 'Vos informations servent uniquement à créer le message de demande sur WhatsApp.',
    'form.back': 'Retour',
    'form.next': 'Continuer',
    'form.submit': 'Envoyer avec WhatsApp',
    'events.wedding': 'Mariage',
    'events.corporate': 'Entreprise',
    'events.birthday': 'Anniversaire',
    'events.anniversary': 'Commémoration',
    'events.party': 'Fête',
    'events.other': 'Autre',
    'cta.eyebrow': 'Planifiez votre événement',
    'cta.title': 'Prêt à créer une expérience culinaire mémorable ?',
    'cta.button': 'Discuter avec Veronica',
    'footer.description': 'Cuisine tanzanienne authentique, accueil chaleureux et service événementiel fiable.',
    'footer.navigation': 'Navigation',
    'footer.services': 'Services',
    'footer.delivery': 'À emporter et livraison',
    'footer.contact': 'Contact',
    'footer.rights': 'Tous droits réservés.',
    'footer.privacy': 'Avis de confidentialité',
    'footer.terms': "Conditions d'utilisation",
    whatsapp: 'Devis WhatsApp',
    menuOpen: 'Ouvrir le menu de navigation',
    menuClose: 'Fermer le menu de navigation',
    validationEvent: "Choisissez un type d'événement avant de continuer.",
    validationFields: 'Vérifiez les champs signalés et fournissez les informations requises.',
    summaryEvent: 'Événement',
    summaryName: 'Nom',
    summaryPhone: 'Téléphone',
    summaryDate: 'Date',
    summaryGuests: 'Personnes',
    summaryLocation: 'Lieu',
    whatsappHeading: 'NOUVELLE DEMANDE TRAITEUR — JVC Catering',
    whatsappClosing: 'Merci de partager les menus, les tarifs et les disponibilités.'
  }
};

let currentLanguage = 'en';
let currentStep = 1;
let menuPreviouslyFocused = null;

const bySelector = (selector, root = document) => root.querySelector(selector);
const allBySelector = (selector, root = document) => Array.from(root.querySelectorAll(selector));
const translate = (key) => translations[currentLanguage][key] ?? translations.en[key] ?? key;

function setLanguage(language) {
  if (!translations[language]) return;
  currentLanguage = language;
  document.documentElement.lang = language;
  document.title = translate('pageTitle');

  const description = bySelector('meta[name="description"]');
  if (description) description.setAttribute('content', translate('pageDescription'));

  allBySelector('[data-i18n]').forEach((element) => {
    const key = element.dataset.i18n;
    const value = translate(key);
    if (value !== key) element.textContent = value;
  });

  allBySelector('[data-language]').forEach((button) => {
    const active = button.dataset.language === language;
    button.classList.toggle('is-active', active);
    button.setAttribute('aria-pressed', String(active));
  });

  const menuToggle = bySelector('[data-menu-toggle]');
  if (menuToggle) {
    const expanded = menuToggle.getAttribute('aria-expanded') === 'true';
    menuToggle.setAttribute('aria-label', expanded ? translate('menuClose') : translate('menuOpen'));
  }

  updateSummary();
  try {
    window.localStorage.setItem('jvc-language', language);
  } catch {
    // The site still works when storage is blocked.
  }
}

function openMenu() {
  const toggle = bySelector('[data-menu-toggle]');
  const navigation = bySelector('[data-navigation]');
  const header = bySelector('[data-header]');
  if (!toggle || !navigation || window.matchMedia('(min-width: 70rem)').matches) return;

  menuPreviouslyFocused = document.activeElement;
  toggle.setAttribute('aria-expanded', 'true');
  toggle.setAttribute('aria-label', translate('menuClose'));
  navigation.classList.add('is-open');
  header?.classList.add('is-open');
  document.body.classList.add('menu-open');
  bySelector('a', navigation)?.focus();
}

function closeMenu({ restoreFocus = true } = {}) {
  const toggle = bySelector('[data-menu-toggle]');
  const navigation = bySelector('[data-navigation]');
  const header = bySelector('[data-header]');
  if (!toggle || !navigation) return;

  toggle.setAttribute('aria-expanded', 'false');
  toggle.setAttribute('aria-label', translate('menuOpen'));
  navigation.classList.remove('is-open');
  header?.classList.remove('is-open');
  document.body.classList.remove('menu-open');

  if (restoreFocus && menuPreviouslyFocused instanceof HTMLElement) {
    menuPreviouslyFocused.focus();
  }
}

function toggleMenu() {
  const toggle = bySelector('[data-menu-toggle]');
  if (!toggle) return;
  const expanded = toggle.getAttribute('aria-expanded') === 'true';
  expanded ? closeMenu() : openMenu();
}

function trapMobileMenuFocus(event) {
  if (event.key !== 'Tab') return;
  const navigation = bySelector('[data-navigation]');
  const toggle = bySelector('[data-menu-toggle]');
  if (!navigation?.classList.contains('is-open') || !toggle) return;

  const focusable = [toggle, ...allBySelector('a[href]', navigation)].filter((element) => !element.hasAttribute('disabled'));
  if (!focusable.length) return;

  const first = focusable[0];
  const last = focusable[focusable.length - 1];
  if (event.shiftKey && document.activeElement === first) {
    event.preventDefault();
    last.focus();
  } else if (!event.shiftKey && document.activeElement === last) {
    event.preventDefault();
    first.focus();
  }
}

function activateMenuTab(tab) {
  const category = tab.dataset.menuTab;
  allBySelector('[data-menu-tab]').forEach((button) => {
    const active = button === tab;
    button.setAttribute('aria-selected', String(active));
    button.tabIndex = active ? 0 : -1;
  });
  allBySelector('[data-menu-panel]').forEach((panel) => {
    panel.hidden = panel.dataset.menuPanel !== category;
  });
}

function handleMenuTabKeys(event) {
  const tabs = allBySelector('[data-menu-tab]');
  const index = tabs.indexOf(event.currentTarget);
  if (index < 0) return;

  let nextIndex = index;
  if (event.key === 'ArrowRight') nextIndex = (index + 1) % tabs.length;
  else if (event.key === 'ArrowLeft') nextIndex = (index - 1 + tabs.length) % tabs.length;
  else if (event.key === 'Home') nextIndex = 0;
  else if (event.key === 'End') nextIndex = tabs.length - 1;
  else return;

  event.preventDefault();
  activateMenuTab(tabs[nextIndex]);
  tabs[nextIndex].focus();
}

function clearFieldError(field) {
  field.removeAttribute('aria-invalid');
  const errorId = `${field.id || field.name}-error`;
  bySelector(`#${CSS.escape(errorId)}`)?.remove();
  const describedBy = (field.getAttribute('aria-describedby') || '')
    .split(/\s+/)
    .filter(Boolean)
    .filter((id) => id !== errorId);
  if (describedBy.length) field.setAttribute('aria-describedby', describedBy.join(' '));
  else field.removeAttribute('aria-describedby');
}

function showFieldError(field) {
  clearFieldError(field);
  field.setAttribute('aria-invalid', 'true');
  const error = document.createElement('p');
  error.className = 'field-error';
  error.id = `${field.id || field.name}-error`;
  error.textContent = field.validationMessage;
  field.insertAdjacentElement('afterend', error);
  field.setAttribute('aria-describedby', error.id);
}

function showFormAlert(message) {
  const alert = bySelector('#form-alert');
  if (!alert) return;
  alert.textContent = message;
  alert.hidden = false;
  alert.focus();
}

function clearFormAlert() {
  const alert = bySelector('#form-alert');
  if (!alert) return;
  alert.hidden = true;
  alert.textContent = '';
}

function validateStep(step) {
  clearFormAlert();
  const form = bySelector('#quote-form');
  if (!form) return false;

  if (step === 1) {
    const selected = bySelector('input[name="eventType"]:checked', form);
    if (!selected) {
      showFormAlert(translate('validationEvent'));
      bySelector('input[name="eventType"]', form)?.focus();
      return false;
    }
    return true;
  }

  if (step === 2) {
    const fields = allBySelector('[data-form-step="2"] input', form);
    let firstInvalid = null;
    fields.forEach((field) => {
      clearFieldError(field);
      if (!field.checkValidity()) {
        showFieldError(field);
        firstInvalid ??= field;
      }
    });
    if (firstInvalid) {
      showFormAlert(translate('validationFields'));
      firstInvalid.focus();
      return false;
    }
  }

  return true;
}

function setStep(step) {
  currentStep = Math.min(3, Math.max(1, step));
  allBySelector('[data-form-step]').forEach((fieldset) => {
    fieldset.hidden = Number(fieldset.dataset.formStep) !== currentStep;
  });
  allBySelector('[data-progress-step]').forEach((item) => {
    const itemStep = Number(item.dataset.progressStep);
    item.classList.toggle('is-current', itemStep === currentStep);
    item.classList.toggle('is-complete', itemStep < currentStep);
    if (itemStep === currentStep) item.setAttribute('aria-current', 'step');
    else item.removeAttribute('aria-current');
  });

  const back = bySelector('[data-form-back]');
  const next = bySelector('[data-form-next]');
  const submit = bySelector('[data-form-submit]');
  if (back) back.hidden = currentStep === 1;
  if (next) next.hidden = currentStep === 3;
  if (submit) submit.hidden = currentStep !== 3;

  if (currentStep === 3) updateSummary();
  const currentFieldset = bySelector(`[data-form-step="${currentStep}"]`);
  currentFieldset?.querySelector('legend')?.focus?.();
}

function formValue(name) {
  const form = bySelector('#quote-form');
  if (!form) return '';
  const field = form.elements.namedItem(name);
  if (field instanceof RadioNodeList) return field.value.trim();
  if (field instanceof HTMLInputElement || field instanceof HTMLTextAreaElement || field instanceof HTMLSelectElement) return field.value.trim();
  return '';
}

function formatDate(value) {
  if (!value) return '';
  const date = new Date(`${value}T12:00:00`);
  if (Number.isNaN(date.getTime())) return value;
  try {
    return new Intl.DateTimeFormat(currentLanguage === 'sw' ? 'sw-TZ' : currentLanguage === 'fr' ? 'fr-FR' : 'en-TZ', {
      dateStyle: 'long'
    }).format(date);
  } catch {
    return value;
  }
}

function updateSummary() {
  const summary = bySelector('#quote-summary');
  if (!summary) return;
  summary.replaceChildren();

  const entries = [
    [translate('summaryEvent'), formValue('eventType')],
    [translate('summaryName'), formValue('customerName')],
    [translate('summaryPhone'), formValue('customerPhone')],
    [translate('summaryDate'), formatDate(formValue('eventDate'))],
    [translate('summaryGuests'), formValue('guestCount')],
    [translate('summaryLocation'), formValue('eventLocation')]
  ];

  entries.forEach(([label, value]) => {
    if (!value) return;
    const row = document.createElement('p');
    const strong = document.createElement('strong');
    const span = document.createElement('span');
    strong.textContent = label;
    span.textContent = value;
    row.append(strong, span);
    summary.append(row);
  });
}

function buildWhatsAppMessage() {
  const lines = [
    `🍽️ *${translate('whatsappHeading')}* 🍽️`,
    '',
    `*${translate('summaryEvent')}:* ${formValue('eventType')}`,
    `*${translate('summaryName')}:* ${formValue('customerName')}`,
    `*${translate('summaryPhone')}:* ${formValue('customerPhone')}`,
    `*${translate('summaryDate')}:* ${formatDate(formValue('eventDate'))}`,
    `*${translate('summaryGuests')}:* ${formValue('guestCount')}`,
    `*${translate('summaryLocation')}:* ${formValue('eventLocation')}`
  ];
  const notes = formValue('eventNotes');
  if (notes) lines.push('', `*${translate('form.notes')}:* ${notes}`);
  lines.push('', translate('whatsappClosing'));
  return lines.join('\n');
}

function submitQuote(event) {
  event.preventDefault();
  if (!validateStep(2)) {
    setStep(2);
    return;
  }
  const url = `https://wa.me/${PRIMARY_WHATSAPP}?text=${encodeURIComponent(buildWhatsAppMessage())}`;
  window.__JVC_LAST_WHATSAPP_URL__ = url;
  const link = document.createElement('a');
  link.href = url;
  link.target = '_blank';
  link.rel = 'noopener noreferrer';
  link.hidden = true;
  document.body.append(link);
  link.click();
  link.remove();
}

function preselectEvent(eventType) {
  const input = bySelector(`input[name="eventType"][value="${CSS.escape(eventType)}"]`);
  if (input) input.checked = true;
  setStep(1);
}

function initializeForm() {
  const form = bySelector('#quote-form');
  if (!form) return;

  const dateInput = bySelector('#event-date');
  if (dateInput) {
    const today = new Date();
    const localDate = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
    dateInput.min = localDate;
  }

  allBySelector('input, textarea, select', form).forEach((field) => {
    field.addEventListener('input', () => clearFieldError(field));
    field.addEventListener('change', () => clearFieldError(field));
  });

  bySelector('[data-form-next]')?.addEventListener('click', () => {
    if (!validateStep(currentStep)) return;
    setStep(currentStep + 1);
  });
  bySelector('[data-form-back]')?.addEventListener('click', () => setStep(currentStep - 1));
  form.addEventListener('submit', submitQuote);
  setStep(1);
}

function initializeReveal() {
  const elements = allBySelector('.reveal');
  if (!('IntersectionObserver' in window) || window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    elements.forEach((element) => element.classList.add('is-visible'));
    return;
  }

  const observer = new IntersectionObserver((entries, currentObserver) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add('is-visible');
      currentObserver.unobserve(entry.target);
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' });

  elements.forEach((element) => observer.observe(element));
}

function initializeSectionTracking() {
  const links = allBySelector('[data-nav-link]');
  const sections = links
    .map((link) => bySelector(link.getAttribute('href')))
    .filter(Boolean);

  if (!('IntersectionObserver' in window)) return;
  const observer = new IntersectionObserver((entries) => {
    const visible = entries
      .filter((entry) => entry.isIntersecting)
      .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
    if (!visible) return;
    links.forEach((link) => {
      const active = link.getAttribute('href') === `#${visible.target.id}`;
      if (active) link.setAttribute('aria-current', 'true');
      else link.removeAttribute('aria-current');
    });
  }, { threshold: [0.2, 0.5], rootMargin: '-25% 0px -60% 0px' });

  sections.forEach((section) => observer.observe(section));
}

function initialize() {
  const header = bySelector('[data-header]');
  const menuToggle = bySelector('[data-menu-toggle]');
  const navigation = bySelector('[data-navigation]');

  menuToggle?.addEventListener('click', toggleMenu);
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && navigation?.classList.contains('is-open')) closeMenu();
    trapMobileMenuFocus(event);
  });

  allBySelector('[data-nav-link]').forEach((link) => {
    link.addEventListener('click', () => closeMenu({ restoreFocus: false }));
  });

  window.addEventListener('resize', () => {
    if (window.matchMedia('(min-width: 70rem)').matches) closeMenu({ restoreFocus: false });
  }, { passive: true });

  const floatingWhatsApp = bySelector('.floating-whatsapp');
  const updateViewportActions = () => {
    header?.classList.toggle('is-scrolled', window.scrollY > 18);
    floatingWhatsApp?.classList.toggle('is-visible', window.scrollY > 320);
  };
  updateViewportActions();
  window.addEventListener('scroll', updateViewportActions, { passive: true });

  allBySelector('[data-language]').forEach((button) => {
    button.addEventListener('click', () => setLanguage(button.dataset.language));
  });

  allBySelector('[data-menu-tab]').forEach((tab) => {
    tab.addEventListener('click', () => activateMenuTab(tab));
    tab.addEventListener('keydown', handleMenuTabKeys);
  });

  allBySelector('.service-quote').forEach((link) => {
    link.addEventListener('click', () => preselectEvent(link.dataset.event));
  });

  const year = new Date().getFullYear();
  allBySelector('[data-current-year]').forEach((element) => { element.textContent = String(year); });

  initializeForm();
  initializeReveal();
  initializeSectionTracking();

  let preferredLanguage = 'en';
  try {
    preferredLanguage = window.localStorage.getItem('jvc-language') || 'en';
  } catch {
    preferredLanguage = 'en';
  }
  setLanguage(translations[preferredLanguage] ? preferredLanguage : 'en');
}

document.addEventListener('DOMContentLoaded', initialize, { once: true });
