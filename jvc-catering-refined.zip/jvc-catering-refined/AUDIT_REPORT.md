# JVC Catering Website — Full Technical Audit

**Audit date:** 4 August 2026  
**Scope reviewed:** complete uploaded deployment backup  
**Refined output:** dependency-free HTML, CSS and JavaScript website

## 1. Executive summary

The uploaded backup was a compiled Vite/React deployment rather than an editable source project. It contained one generated JavaScript bundle, one generated CSS bundle, local images, and an HTML shell. The original source components, `package.json`, and build configuration were not present.

Because the application source was unavailable, attempting to patch the minified React bundle would have produced fragile code. The website was therefore rebuilt as a maintainable, self-contained HTML/CSS/JavaScript implementation that preserves the business content, three-language support, menu categories, client logos, services, founder information, and WhatsApp quotation workflow.

The refined build has no runtime framework dependency, no remote image dependency, no Google Fonts dependency, and no external JavaScript dependency.

## 2. Highest-risk findings in the uploaded backup

### Critical

1. **The website backup was build output, not source code**
   - The HTML referenced generated files such as `assets/index-CRHT5pMU.js` and `assets/index-BthWwDln.css`.
   - Those filenames change whenever Vite rebuilds the project.
   - Editing them directly would be difficult to maintain and easy to break.

2. **Image payload was excessively large**
   - Original reviewed image payload: approximately **28.8 MB**.
   - Several files had misleading extensions. Examples:
     - `maandazi.png` contained JPEG data and was approximately 10.4 MB at 7360×4912.
     - `mshikaki.png` contained JPEG data and was approximately 5.9 MB.
     - `nyamachoma.png` contained AVIF data.
     - `pilau.png` and `walinazi.png` contained WebP data.
     - `favicon.png` contained JPEG data.
   - These inconsistencies can cause incorrect MIME delivery, wasted bandwidth, browser decoding delays, and cache problems.

3. **Remote assets reduced reliability**
   - Hero, service, and menu images depended on Unsplash and Wikimedia URLs.
   - A third-party outage, rate limit, URL change, or Content Security Policy restriction could leave sections blank.

4. **Hero preload did not match the rendered request mode**
   - Browser testing reproduced a credentials-mode mismatch warning for the image preload.
   - The preload was therefore not reliably reusable and could create unnecessary duplicate work.

5. **Primary contact number was inconsistent**
   - The quote form and main contact section used `+255 767 602 509`.
   - The old footer used `+255 767 620 509`.
   - The refined build consistently uses `+255 767 602 509`, because that was the number used by the original quote and primary contact flow.
   - **The business owner should confirm this number before final production deployment.**

### Accessibility and usability

6. **Mobile navigation state was not exposed correctly**
   - The original menu button did not maintain `aria-expanded` or `aria-controls` correctly.
   - Escape did not close the mobile menu during testing.
   - Focus management was incomplete.

7. **Broken footer links**
   - Facebook, Privacy Policy, and Terms of Service used `href="#"`.
   - These links behaved like broken controls and could unexpectedly move the page to the top.

8. **Touch targets were too small**
   - The original runtime audit found many interactive controls below the recommended 44×44 CSS-pixel target size.

9. **No reduced-motion support**
   - The original CSS contained no `prefers-reduced-motion` handling.

10. **No robust keyboard focus treatment**
    - The stylesheet did not provide a consistent `:focus-visible` system.

11. **Heading hierarchy contained avoidable jumps**
    - The original page used multiple `h5` headings directly after higher-level headings, weakening document structure for assistive technology.

12. **Initial HTML contained almost no page content**
    - The body only contained `<div id="root"></div>`.
    - If JavaScript failed or was blocked, visitors and crawlers received no meaningful page content.

### SEO and metadata

13. **Missing character encoding declaration**
    - The original document lacked `<meta charset="utf-8">` near the beginning of the head.

14. **Obsolete meta keywords**
    - `meta name="keywords"` added noise without meaningful modern search benefit.

15. **Structured data type was inappropriate**
    - The backup used `"@type": "CateringBusiness"`.
    - The refined implementation uses `LocalBusiness` with a catering service catalogue.

16. **Social image was externally hosted**
    - WhatsApp, LinkedIn, and other previews depended on a remote stock image.

17. **Referenced Apple touch icon did not exist**
    - The HTML referenced `/apple-touch-icon.png`, but the backup did not contain that file.

18. **No robots, sitemap, manifest, or custom 404 page**

### Security and deployment

19. **Apache configuration only handled SPA rewriting**
    - It did not configure security headers, compression, cache policy, directory listing protection, HTTPS redirection, or an error document.

20. **No Vercel security-header configuration was included**

21. **Inline font `onload` JavaScript complicated CSP enforcement**

## 3. Improvements implemented

### Architecture

- Rebuilt the website using editable, readable:
  - `index.html`
  - `css/styles.css`
  - `js/main.js`
- Removed runtime dependency on React, Vite, Google Fonts, Unsplash, Wikimedia, and icon libraries.
- Kept the site deployable as ordinary static files on Apache, InfinityFree, Contabo, Vercel, Netlify, or similar hosting.

### Performance

- Converted and resized all supplied image assets to correctly encoded WebP files.
- Created separate responsive hero images for mobile and larger screens.
- Added intrinsic image width and height attributes.
- Added lazy loading and asynchronous decoding below the fold.
- Kept the hero eager with `fetchpriority="high"` and an exact matching preload.
- Reduced reviewed image bytes from approximately **28.8 MB to 2.9 MB**, a reduction of approximately **89.95%**.
- Removed remote font and image handshakes.
- Added long-lived immutable caching for version-stable assets.
- Added HTML revalidation and compression rules.

### Accessibility

- Added a skip link.
- Added semantic `header`, `nav`, `main`, `section`, `address`, and `footer` landmarks.
- Enforced one meaningful `h1` and a logical heading hierarchy.
- Added descriptive image alternative text.
- Added minimum 44×44 touch targets.
- Added visible keyboard focus with `:focus-visible`.
- Added `prefers-reduced-motion` support.
- Added a keyboard-operable ARIA tab interface for menu categories.
- Added mobile-menu focus management, Escape handling, focus trapping, `aria-expanded`, and `aria-controls`.
- Added properly associated labels, required-state validation, inline field errors, and an accessible form error summary.
- Added safe external-link `rel="noopener noreferrer"` attributes.
- Removed all empty `href="#"` links.

### Reliability

- Made all visible website imagery local.
- Replaced generated framework bundles with maintainable source files.
- Added a working 404 page.
- Added safe progressive behavior: core page content remains readable if JavaScript is disabled.
- Added self-contained English, Kiswahili, and French interface translations.
- Added robust WhatsApp message construction using `encodeURIComponent`.
- Normalized the primary WhatsApp contact number throughout the site.

### SEO and sharing

- Added UTF-8 metadata.
- Refined the page title and description.
- Added local Open Graph and X/Twitter card metadata.
- Added a local 1200×630 social-sharing image.
- Added valid `LocalBusiness` JSON-LD.
- Added `robots.txt`, `sitemap.xml`, and `site.webmanifest`.
- Generated correctly encoded favicon and Apple touch icon files.

### Security and hosting

- Added Apache `.htaccess` rules for:
  - HTTPS redirection
  - HSTS
  - Content Security Policy
  - clickjacking protection
  - MIME sniffing protection
  - referrer policy
  - permissions policy
  - compression
  - caching
  - directory listing protection
  - 404 handling
- Added equivalent Vercel headers in `vercel.json`.

## 4. Validation completed

The refined site was tested in headless Chromium at:

- **390×844 mobile**
- **768×1024 tablet**
- **1440×1000 desktop**

Automated smoke tests confirmed:

- no JavaScript runtime errors
- no failed local network requests
- no horizontal overflow
- one `h1`
- one `main` landmark
- no duplicate IDs
- no missing image alt attributes
- no unlabeled form fields
- no empty buttons or links
- no unsafe target-blank links
- no `href="#"` links
- no failed visible images
- no touch targets below 44×44 in the tested UI
- mobile menu opens and closes correctly
- Escape closes the mobile menu
- focus moves into the mobile navigation
- language switching works
- keyboard arrow navigation works for menu tabs
- the quotation flow reaches the confirmation step
- the WhatsApp URL and encoded message are generated correctly

Test output is stored in `tests/results/smoke-results.json`.

## 5. Analytics limitation

No Google Analytics export, Search Console report, Vercel Speed Insights report, or real-user Core Web Vitals dataset was included in the backup. Therefore, this audit does not invent field-performance scores.

The performance conclusions above are based on measurable source facts, asset sizes, runtime browser warnings, DOM inspection, and controlled mobile/tablet/desktop smoke testing. After deployment, real-user monitoring should be added before claiming specific LCP, INP, or CLS improvements.

## 6. Required business confirmations before final launch

1. Confirm that the primary WhatsApp number is **+255 767 602 509** rather than **+255 767 620 509**.
2. Confirm that `https://jvc-catering.vercel.app/` remains the preferred canonical URL. If a custom domain is live, update canonical, Open Graph, JSON-LD, sitemap, and robots URLs.
3. Review the draft privacy notice and website terms before accepting online payments or deposits.
4. Confirm the visible statements `Established 2016`, `25+ years`, `500+ events`, and the listed client organisations.

## 7. Deployment recommendation

Deploy the contents of the refined folder directly to the web root. Do not upload the parent folder itself unless the domain is intended to show a subdirectory in the URL.
